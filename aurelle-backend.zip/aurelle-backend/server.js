require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { z } = require('zod');
const { Pool } = require('pg');

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 24) throw new Error('Set JWT_SECRET (24+ chars) in .env');

const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false });
const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: (process.env.CORS_ORIGIN || '*').split(',') }));
app.use(express.json({ limit: '100kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, max: 120 }));

class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const CATEGORIES = ['Shoes', 'Bags', 'Watches', 'Makeup', 'Luggage', 'Other'];
const STATUSES = ['New', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];
const idParam = v => { const n = Number(v); if (!Number.isInteger(n) || n < 1) throw new HttpError(400, 'Invalid id'); return n; };

function auth(req, _res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer /, '');
  try { req.admin = jwt.verify(token, process.env.JWT_SECRET); next(); }
  catch { next(new HttpError(401, 'Login required')); }
}

app.get('/api/health', (_req, res) => res.json({ ok: true }));

/* ---------- Public: catalog ---------- */
app.get('/api/products', wrap(async (req, res) => {
  const { category } = req.query;
  const params = [], where = ['active'];
  if (category && category !== 'All') {
    if (!CATEGORIES.includes(category)) throw new HttpError(400, 'Unknown category');
    params.push(category); where.push(`category = $${params.length}`);
  }
  const { rows } = await pool.query(`SELECT id, name, category, price_pkr, stock, emoji, image_url FROM products WHERE ${where.join(' AND ')} ORDER BY id`, params);
  res.json(rows);
}));

app.get('/api/products/:id', wrap(async (req, res) => {
  const { rows } = await pool.query('SELECT id, name, category, price_pkr, stock, emoji, image_url FROM products WHERE id=$1 AND active', [idParam(req.params.id)]);
  if (!rows[0]) throw new HttpError(404, 'Product not found');
  res.json(rows[0]);
}));

/* ---------- Public: place and track orders ---------- */
const orderSchema = z.object({
  customerName: z.string().trim().min(2).max(100),
  phone: z.string().trim().regex(/^(\+92|0)?3\d{9}$|^\+?\d{9,15}$/, 'Invalid phone number'),
  address: z.string().trim().min(5).max(300),
  city: z.string().trim().min(2).max(60),
  paymentMethod: z.enum(['cod', 'bank_transfer', 'wallet']),
  items: z.array(z.object({ productId: z.number().int().positive(), qty: z.number().int().min(1).max(20) })).min(1).max(30)
});

app.post('/api/orders', rateLimit({ windowMs: 60_000, max: 10 }), wrap(async (req, res) => {
  const parsed = orderSchema.safeParse(req.body);
  if (!parsed.success) throw new HttpError(400, parsed.error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join('; '));
  const o = parsed.data;
  const qtyById = new Map();
  for (const i of o.items) qtyById.set(i.productId, (qtyById.get(i.productId) || 0) + i.qty);

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Lock rows so two customers cannot buy the last item at once. Prices come from the DB, never the client.
    const { rows: prods } = await client.query('SELECT id, name, price_pkr, stock FROM products WHERE id = ANY($1) AND active FOR UPDATE', [[...qtyById.keys()]]);
    if (prods.length !== qtyById.size) throw new HttpError(400, 'One or more products are unavailable');
    let total = 0;
    for (const p of prods) {
      const qty = qtyById.get(p.id);
      if (p.stock < qty) throw new HttpError(409, `Not enough stock for ${p.name} (only ${p.stock} left)`);
      total += p.price_pkr * qty;
    }
    const code = 'AU' + crypto.randomBytes(4).toString('hex').toUpperCase();
    const { rows: [order] } = await client.query(
      `INSERT INTO orders (code, customer_name, phone, address, city, payment_method, total_pkr)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, code, status, total_pkr, created_at`,
      [code, o.customerName, o.phone, o.address, o.city, o.paymentMethod, total]);
    for (const p of prods) {
      const qty = qtyById.get(p.id);
      await client.query('INSERT INTO order_items (order_id, product_id, name, price_pkr, qty) VALUES ($1,$2,$3,$4,$5)', [order.id, p.id, p.name, p.price_pkr, qty]);
      await client.query('UPDATE products SET stock = stock - $1 WHERE id = $2', [qty, p.id]);
    }
    await client.query('COMMIT');
    res.status(201).json({ code: order.code, status: order.status, total_pkr: order.total_pkr, created_at: order.created_at });
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}));

// Customers track an order with its code AND the phone number used to place it.
app.get('/api/orders/:code', wrap(async (req, res) => {
  const { rows } = await pool.query('SELECT id, code, status, total_pkr, created_at, phone FROM orders WHERE code=$1', [req.params.code.toUpperCase()]);
  const o = rows[0];
  if (!o || String(req.query.phone || '').replace(/\D/g, '').slice(-10) !== o.phone.replace(/\D/g, '').slice(-10)) throw new HttpError(404, 'Order not found');
  const { rows: items } = await pool.query('SELECT name, price_pkr, qty FROM order_items WHERE order_id=$1', [o.id]);
  res.json({ code: o.code, status: o.status, total_pkr: o.total_pkr, created_at: o.created_at, items });
}));

/* ---------- Admin ---------- */
app.post('/api/admin/login', rateLimit({ windowMs: 15 * 60_000, max: 10 }), wrap(async (req, res) => {
  const { email = '', password = '' } = req.body || {};
  const { rows } = await pool.query('SELECT id, password_hash FROM admins WHERE email=$1', [String(email).toLowerCase()]);
  const ok = rows[0] && await bcrypt.compare(String(password), rows[0].password_hash);
  if (!ok) throw new HttpError(401, 'Wrong email or password');
  res.json({ token: jwt.sign({ id: rows[0].id }, process.env.JWT_SECRET, { expiresIn: '12h' }) });
}));

const productSchema = z.object({
  name: z.string().trim().min(1).max(150),
  category: z.enum(CATEGORIES),
  price_pkr: z.number().int().min(0),
  stock: z.number().int().min(0),
  emoji: z.string().max(8).optional(),
  image_url: z.string().url().nullable().optional(),
  active: z.boolean().optional()
});

app.get('/api/admin/products', auth, wrap(async (_req, res) => {
  res.json((await pool.query('SELECT * FROM products ORDER BY id')).rows);
}));

app.post('/api/admin/products', auth, wrap(async (req, res) => {
  const p = productSchema.parse(req.body);
  const { rows } = await pool.query(
    'INSERT INTO products (name, category, price_pkr, stock, emoji, image_url, active) VALUES ($1,$2,$3,$4,COALESCE($5,\'🛍️\'),$6,COALESCE($7,TRUE)) RETURNING *',
    [p.name, p.category, p.price_pkr, p.stock, p.emoji, p.image_url ?? null, p.active]);
  res.status(201).json(rows[0]);
}));

app.patch('/api/admin/products/:id', auth, wrap(async (req, res) => {
  const p = productSchema.partial().parse(req.body);
  const keys = Object.keys(p);
  if (!keys.length) throw new HttpError(400, 'Nothing to update');
  const sets = keys.map((k, i) => `${k} = $${i + 1}`).join(', '); // keys are whitelisted by zod
  const { rows } = await pool.query(`UPDATE products SET ${sets} WHERE id = $${keys.length + 1} RETURNING *`, [...keys.map(k => p[k]), idParam(req.params.id)]);
  if (!rows[0]) throw new HttpError(404, 'Product not found');
  res.json(rows[0]);
}));

app.delete('/api/admin/products/:id', auth, wrap(async (req, res) => {
  const r = await pool.query('DELETE FROM products WHERE id=$1', [idParam(req.params.id)]);
  if (!r.rowCount) throw new HttpError(404, 'Product not found');
  res.status(204).end();
}));

app.get('/api/admin/orders', auth, wrap(async (req, res) => {
  const params = [], where = [];
  if (req.query.status) { if (!STATUSES.includes(req.query.status)) throw new HttpError(400, 'Unknown status'); params.push(req.query.status); where.push(`o.status = $${params.length}`); }
  const { rows } = await pool.query(
    `SELECT o.*, COALESCE(json_agg(json_build_object('name', i.name, 'price_pkr', i.price_pkr, 'qty', i.qty)) FILTER (WHERE i.id IS NOT NULL), '[]') AS items
     FROM orders o LEFT JOIN order_items i ON i.order_id = o.id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} GROUP BY o.id ORDER BY o.created_at DESC LIMIT 200`, params);
  res.json(rows);
}));

app.patch('/api/admin/orders/:id/status', auth, wrap(async (req, res) => {
  const status = req.body && req.body.status;
  if (!STATUSES.includes(status)) throw new HttpError(400, 'Unknown status');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: [cur] } = await client.query('SELECT status FROM orders WHERE id=$1 FOR UPDATE', [idParam(req.params.id)]);
    if (!cur) throw new HttpError(404, 'Order not found');
    // Cancelling puts the stock back (once).
    if (status === 'Cancelled' && cur.status !== 'Cancelled')
      await client.query('UPDATE products p SET stock = p.stock + i.qty FROM order_items i WHERE i.order_id=$1 AND i.product_id = p.id', [req.params.id]);
    if (cur.status === 'Cancelled' && status !== 'Cancelled') throw new HttpError(409, 'A cancelled order cannot be reopened. Create a new order.');
    const { rows } = await client.query('UPDATE orders SET status=$1 WHERE id=$2 RETURNING *', [status, req.params.id]);
    await client.query('COMMIT');
    res.json(rows[0]);
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}));

app.get('/api/admin/stats', auth, wrap(async (_req, res) => {
  const { rows: [s] } = await pool.query(`SELECT
    (SELECT count(*) FROM products)::int AS products,
    (SELECT count(*) FROM orders)::int AS orders,
    (SELECT count(*) FROM orders WHERE status='New')::int AS new_orders,
    COALESCE((SELECT sum(total_pkr) FROM orders WHERE status <> 'Cancelled'),0)::int AS revenue_pkr`);
  res.json(s);
}));

/* ---------- Errors ---------- */
app.use((_req, _res, next) => next(new HttpError(404, 'Not found')));
app.use((err, _req, res, _next) => {
  if (err instanceof z.ZodError) return res.status(400).json({ error: err.issues.map(i => `${i.path.join('.')}: ${i.message}`).join('; ') });
  if (err.status) return res.status(err.status).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong' });
});

app.listen(process.env.PORT || 3000, () => console.log('Aurelle API running on port ' + (process.env.PORT || 3000)));
